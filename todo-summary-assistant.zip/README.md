# Todo Summary Assistant

A full-stack application that allows users to create and manage personal to-do items, summarize pending to-dos using an LLM, and send the generated summary to a Slack channel.

## Features

- Create, edit, and delete to-do items
- Mark to-dos as completed
- Generate AI summaries of pending to-dos
- Send summaries to a Slack channel

## Tech Stack

- **Frontend**: React, Next.js, Tailwind CSS, shadcn/ui
- **Backend**: Next.js API Routes
- **Database**: Supabase (PostgreSQL)
- **LLM Integration**: OpenAI
- **Slack Integration**: Incoming Webhooks

## Setup Instructions

### Prerequisites

- Node.js 18+ and npm
- Supabase account
- OpenAI API key
- Slack workspace with permission to create webhooks

### Environment Variables

Create a `.env.local` file in the root directory with the following variables:

\`\`\`
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key
OPENAI_API_KEY=your_openai_api_key
SLACK_WEBHOOK_URL=your_slack_webhook_url
\`\`\`

### Slack Webhook Setup

1. Go to your Slack workspace
2. Navigate to the Slack API website: https://api.slack.com/apps
3. Click "Create New App" and select "From scratch"
4. Name your app and select your workspace
5. In the sidebar, click on "Incoming Webhooks"
6. Toggle "Activate Incoming Webhooks" to On
7. Click "Add New Webhook to Workspace"
8. Select the channel where you want to receive the summaries
9. Copy the Webhook URL and add it to your environment variables as `SLACK_WEBHOOK_URL`

### Installation and Running

1. Clone the repository
2. Install dependencies:
   \`\`\`
   npm install
   \`\`\`
3. Run the development server:
   \`\`\`
   npm run dev
   \`\`\`
4. Open [http://localhost:3000](http://localhost:3000) in your browser

## Deployment

This application can be easily deployed to Vercel:

1. Push your code to a GitHub repository
2. Import the repository in Vercel
3. Add the environment variables in the Vercel project settings
4. Deploy

## License

MIT
